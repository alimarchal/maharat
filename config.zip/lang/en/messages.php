<?php

// lang/en/messages.php

return [
    'welcome' => 'Welcome to our application!',
];