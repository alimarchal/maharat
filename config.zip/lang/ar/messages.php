<?php

// lang/ar/messages.php
return [
    'welcome' => 'مرحبا بكم في تطبيقنا!',
];