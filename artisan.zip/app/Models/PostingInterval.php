<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PostingInterval extends Model
{
    /** @use HasFactory<\Database\Factories\PostingIntervalFactory> */
    use HasFactory;
}
