<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProcessStepDesignation extends Model
{
    /** @use HasFactory<\Database\Factories\ProcessStepDesignationFactory> */
    use HasFactory;
}
